def saludar():
    print('hola, te estoy saludando desde la funcion desde la funcion saludar')

class Saludo():
    def __init__(self):
        print('hola, te estoy saludando desde el init de la clase saludo')
