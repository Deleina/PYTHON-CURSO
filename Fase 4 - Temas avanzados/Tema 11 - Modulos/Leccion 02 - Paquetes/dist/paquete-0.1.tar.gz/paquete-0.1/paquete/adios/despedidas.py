def despedirse():
    print('adios, me estoy saludando desde la funcion desde la funcion despedirse de el modulo despedirse')

class Despedida():
    def __init__(self):
        print('hola, me estoy despidiendo  desde el init de la clase Despedida')
